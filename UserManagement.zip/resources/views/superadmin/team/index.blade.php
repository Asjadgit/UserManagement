@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Team Management</div>
                    <div class="card-body">
                        <a href="{{ route('teams.create') }}" class="btn btn-primary mb-4">Add New Team</a>

                        <table id="teamsTable" class="table table-bordered mt-3 p-2">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($teams as $team)
                                    <tr>
                                        <td>{{ $team->id }}</td>
                                        <td>{{ $team->name }}</td>
                                        <td>
                                            <a href="{{ route('teams.members', $team->id) }}" class="btn btn-sm btn-success">
                                                Add Member
                                            </a>

                                            <a href="{{ route('teams.show', $team->id) }}" class="btn btn-sm btn-info">
                                                Show Members
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#teamsTable').DataTable({
                "paging": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
                "lengthMenu": [
                    [5, 10, 25, 50, -1],
                    [5, 10, 25, 50, "All"]
                ],
                "language": {
                    "search": "Filter records:"
                }
            });
        });
    </script>
@endsection
