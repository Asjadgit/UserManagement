<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\VisibilityGroup;
use App\Models\VisibilitySetting;

class VisibilityGroupController extends Controller
{
    public function index(Request $request)
    {
        // Fetch all visibility groups with their parent and children relationships
        $groups = VisibilityGroup::with(['parent', 'children', 'users'])->get();
        if ($request->wantsJson()) {
            return response()->json([
                'groups' => $groups,
            ], 201);
        }

        return view('visibility-groups.index', compact('groups'));
    }


    public function create(Request $request)
    {
        $visibilityGroups = VisibilityGroup::with('users')->get();

        // If a parent_id is provided, load sub-group creation form
        if ($request->has('parent_id')) {
            $parentGroup = VisibilityGroup::findOrFail($request->parent_id);
            return view('visibility-groups.create-sub', compact('parentGroup'));
        }

        // Otherwise, load the main group creation form
        return view('visibility-groups.create', compact('visibilityGroups'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'description' => 'nullable|string',
            'parent_id' => 'nullable|integer',
        ]);

        $group = VisibilityGroup::create([
            'name' => $request->name,
            'description' => $request->description,
            'parent_id' => $request->parent_id,
        ]);

        // Retrieve all permissions
        $groups = VisibilityGroup::all();

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Group created successfully.',
                'group' => $group,
            ], 201);
        } else {
            return redirect()->route('visibility_groups.index')->with('success', 'Group Added Successfully');
        }
    }

    public function show(Request $request,string $id)
    {
        $group = VisibilityGroup::with('users')->findOrFail($id);
        $visibilitySettings = VisibilitySetting::where('visibility_group_id', $id)->get();

        if ($request->wantsJson()) {
            return response()->json([
                'group' => $group,
                'visibilitySettings' => $visibilitySettings,
            ], 201);
        }

        return view('visibility-groups.show', compact('group', 'visibilitySettings'));
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, $id)
    {
        $group = VisibilityGroup::with(['parent', 'children'])->findOrFail($id);
        $visibilityGroups = VisibilityGroup::where('id', '!=', $id)->get(); // Exclude current group from parent selection

        if ($request->wantsJson()) {
            return response()->json([
                'group' => $group,
                'visibilityGroups' => $visibilityGroups
            ], 200);
        } else {
            return view('visibility-groups.edit', compact('group', 'visibilityGroups'));
        }
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Validate input fields
        $request->validate([
            'name' => 'required|string|max:70',
            'description' => 'nullable|string|max:255',
            'parent_id' => 'nullable|exists:visibility_groups,id',
        ]);

        // Find the group or fail
        $group = VisibilityGroup::findOrFail($id);

        // Update the group details
        $group->update([
            'name' => $request->name,
            'description' => $request->description,
            'parent_id' => $request->parent_id,
        ]);

        // Handle JSON and Redirect Responses
        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Group updated successfully.',
                'group' => $group,
            ], 200);
        } else {
            return redirect()->route('visibility_groups.index')
                ->with('success', 'Group updated successfully.');
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, $id)
    {
        try {
            $group = VisibilityGroup::find($id);

            // Now safely delete the group
            $group->delete();
            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'Group deleted successfully.',
                ], 201);
            }

            return redirect()->route('visibility_groups.index')->with('success', 'Group deleted successfully.');
        } catch (\Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    public function showUser($id)
    {
        $users = User::all();
        return view('visibility-groups.assign', compact('users'));
    }
}
