<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Models\Team;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TeamController extends Controller
{
    public function index(Request $request)
    {
        $teams = Team::all();

        if ($request->wantsJson()) {
            return response()->json(['teams' => $teams]);
        }

        return view('superadmin.team.index', compact('teams'));
    }

    public function create()
    {
        return view('superadmin.team.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:teams',
        ]);

        $team = Team::create(['name' => $request->name]);

        if ($request->wantsJson()) {
            return response()->json(['message' => 'Team created successfully', 'team' => $team]);
        }

        return redirect()->route('teams.index')->with('success', 'Team Created Successfully');
    }

    public function show(Request $request,$id)
    {
        $team = Team::with('users')->find($id);

        if ($request->wantsJson()) {
            return response()->json(['message' => 'Team Members', 'team' => $team]);
        }

        return view('superadmin.team.show', compact('team'));
    }


    public function showMembers(Request $request, Team $team)
    {
        // Fetch users who are NOT "Super Admin" along with their team information
        $users = User::whereDoesntHave('roles', function ($query) {
            $query->where('name', 'Super Admin');
        })->with('teams')->get(); // Include teams in the query

        // Fetch IDs of users already in the current team
        $teamMemberIds = $team->users()->pluck('users.id')->toArray();

        // Prepare user data with team information
        $usersData = $users->map(function ($user) {
            return [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'teams' => $user->teams->pluck('name')->toArray(), // Get all teams the user is in
            ];
        });

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Team members fetched successfully',
                'team' => $team,
                'users' => $usersData, // Include team details
                'selected_users' => $teamMemberIds
            ]);
        }

        return view('superadmin.team.members', compact('team', 'usersData', 'teamMemberIds'));
    }





    public function addMembersToTeam(Request $request, $teamId)
    {
        $team = Team::findOrFail($teamId);

        $request->validate([
            'user_ids' => 'array', // Allow empty array if no users are selected
            'user_ids.*' => 'exists:users,id' // Ensures each user ID exists in the users table
        ]);

        // Sync users (automatically adds new users & removes unchecked ones)
        $team->users()->sync($request->user_ids ?? []);

        return response()->json([
            'message' => 'Team members updated successfully!',
            'team' => $team->load('users') // Load users for reference
        ]);
    }
}
