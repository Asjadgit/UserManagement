<?php

namespace App\Http\Controllers\SuperAdmin;

use Log;
use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        // Generate token
        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'message' => 'Login successful',
            'token' => $token,
            'user' => $user
        ], 200);
    }

    // All these gates are defined in the AuthServiceProvider in the app/Providers directory

    public function index(Request $request)
    {
        $users = User::with('roles.permissions')->get(); // Eager load roles and permissions

        // Check if the request expects JSON
        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Users retrieved successfully.',
                'users' => $users
            ], 200);
        } else {
            // Return the Blade view for non-JSON requests
            return view('superadmin.users.index', compact('users'));
        }
    }



    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $req)
    {
        // Check if the user is allowed to create users
        if (!Gate::allows('user-creation')) {
            if ($req->wantsJson()) {
                return response()->json(['error' => 'You do not have permission to create new user.'], 403);
            }

            return abort(403, 'You are unauthorized for this task.');
        }

        return view('superadmin.users.create');
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            if (!auth()->check()) {
                Log::error('Unauthorized Access Attempt');
                return response()->json(['message' => 'Unauthorized'], 401);
            }

            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users',
                'password' => 'required|string|min:8',
                'role' => 'nullable|string|exists:roles,name',
                'permissions' => 'nullable|array',
                'permissions.*' => 'string|exists:permissions,name'
            ]);

            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);

            Log::info('User created successfully', ['user' => $user]);

            // Assign Role
            // $user->assignRole($request->role);
            // Log::info('Role assigned successfully', ['role' => $request->role]);

            // Assign Permissions (if provided)
            // if ($request->has('permissions')) {
            //     $role = Role::where('name', $request->role)->first();
            //     if ($role) {
            //         $role->givePermissionTo($request->permissions);
            //         Log::info('Permissions assigned successfully', ['permissions' => $request->permissions]);
            //     } else {
            //         Log::error('Role not found for permission assignment', ['role' => $request->role]);
            //     }
            // }

            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'User created successfully',
                    'user' => $user
                ], 201);
            } else {
                return redirect()->route('users.index')->with('success', 'User Created Successfully');
            }
        } catch (\Exception $e) {
            return response()->json($e->getMessage());
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(Request $request, string $id)
    {
        if (!Gate::allows('view-user')) {
            if ($request->wantsJson()) {
                return response()->json(['error' => 'You do not have permission to view this user.'], 403);
            }
            return abort(403, 'You are unauthorized for this task.');
        }


        $user = User::with(['roles.permissions'])->findOrFail($id);
        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'User Details',
                'user' => $user
            ], 201);
        }
        return view('superadmin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $req, string $id)
    {
        if (!Gate::allows('edit-user')) {
            if ($req->wantsJson()) {
                return response()->json(['error' => 'You do not have permission to edit this user.'], 403);
            }

            return abort(403, 'You are Unauthorized for this task.');
        }

        $user = User::with('roles.permissions')->where('id', $id)->first();

        if ($req->wantsJson()) {
            return response()->json([
                'user' => $user
            ], 200);
        } else {
            return view('superadmin.users.edit', compact('user'));
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            if (!auth()->check()) {
                Log::error('Unauthorized Access Attempt');
                return response()->json(['message' => 'Unauthorized'], 401);
            }

            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users,email,' . $id,
                'role' => 'nullable|string|exists:roles,name',
            ]);

            $user = User::find($id);
            if (!$user) {
                return response()->json(['message' => 'User not found'], 404);
            }

            $user->update([
                'name' => $request->name,
                'email' => $request->email,
            ]);

            Log::info('User updated successfully', ['user' => $user]);

            // Update Role (Only Role, No Permissions)
            $user->syncRoles([$request->role]);
            Log::info('Role updated successfully', ['role' => $request->role]);

            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'User updated successfully',
                    'user' => $user
                ], 200);
            } else {
                return redirect()->route('users.index')->with('success', 'User Updated Successfully');
            }
        } catch (\Exception $e) {
            return response()->json($e->getMessage(), 500);
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $req, string $id)
    {
        if (!Gate::allows('user-deletion')) {
            if ($req->wantsJson()) {
                return response()->json(['error' => 'You do not have permission to assign any role this user.'], 403);
            }

            return abort(403, 'You are Unauthorized for this task.');
        }
        try {
            // if (!auth()->check()) {
            //     Log::error('Unauthorized Access Attempt');
            //     return response()->json(['message' => 'Unauthorized'], 401);
            // }

            $user = User::find($id);
            if (!$user) {
                return response()->json(['message' => 'User not found'], 404);
            }

            $user->delete();
            Log::info('User deleted successfully', ['user_id' => $id]);

            if (request()->wantsJson()) {
                return response()->json(['message' => 'User deleted successfully'], 200);
            } else {
                return redirect()->route('users.index')->with('success', 'User Deleted Successfully');
            }
        } catch (\Exception $e) {
            return response()->json(['message' => 'Error deleting user', 'error' => $e->getMessage()], 500);
        }
    }


    public function assignRoles(Request $req, $id)
    {
        if (!Gate::allows('assign-role')) {
            if ($req->wantsJson()) {
                return response()->json(['error' => 'You do not have permission to assign any role this user.'], 403);
            }

            return abort(403, 'You are Unauthorized for this task.');
        }

        $user = User::with('roles.permissions')->find($id);
        $roles = Role::all(); // Fetch all roles
        $permissions = Permission::all(); // Fetch all permissions

        if (request()->wantsJson()) {
            return response()->json([
                'user' => $user,
                'assigned_roles' => $user->roles->pluck('name'),
                // 'all_roles' => $roles,
                'assigned_permissions' => $user->roles->flatMap->permissions->pluck('name')->unique(),
                // 'all_permissions' => $permissions
            ]);
        }

        return view('superadmin.users.assign-roles', compact('user', 'roles', 'permissions'));
    }


    public function updateRoles(Request $request, $id)
    {
        $user = User::findOrFail($id);

        // Validate request
        $request->validate([
            'roles' => 'array',
            'roles.*' => 'exists:roles,id',
        ]);

        // Sync selected roles
        $user->roles()->sync($request->roles ?? []);

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Roles updated successfully!',
                'user' => $user->load('roles')
            ], 200);
        }

        return redirect()->route('users.index')->with('success', 'Roles updated successfully!');
    }
}
