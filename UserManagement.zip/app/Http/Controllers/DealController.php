<?php

namespace App\Http\Controllers;

use App\Models\Deal;
use Illuminate\Http\Request;
use App\Models\VisibilityGroup;
use App\Models\VisibilitySetting;

class DealController extends Controller
{
    public function index(Request $request)
    {
        $deals = Deal::all();
        if ($request->wantsJson()) {
            return response()->json([
                'leads' => $deals,
            ], 201);
        } else {
            return view('deals.index', compact('deals'));
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('deals.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
        ]);

        $deals = Deal::create(['name' => $request->name]);

        // Retrieve all permissions
        $deals = Deal::all();

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'deals created successfully.',
                'deals' => $deals,
            ], 201);
        } else {
            return redirect()->route('deals.index')->with('success', 'deal Added Successfully');
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, $id)
    {
        $deals = Deal::find($id);
        if ($request->wantsJson()) {
            return response()->json([
                'deals' => $deals,
            ], 200);
        } else {
            return view('deals.edit', compact('deals'));
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string',
        ]);

        $deals = Deal::find($id);

        $deals->update(['name' => $request->name]);

        // Retrieve all permissions
        $deals = Deal::all();
        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'leads updated successfully.',
                'deals' => $deals,
            ], 201);
        } else {
            return redirect()->route('deals.index')->with('success', 'deal updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id, Request $request)
    {

        // First, update the guard to 'web' before deleting
        $deals = Deal::where('id', $id)->first();

        if (!$deals) {
            return response()->json([
                'error' => 'deals not found.'
            ], 404);
        }

        // Now safely delete the permission
        $deals->delete();

        // Return response based on request type
        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'deals deleted successfully.',
            ], 201);
        } else {
            return redirect()->route('deals.index')->with('success', 'deals deleted successfully.');
        }
    }

    // Show assign group form
    public function assignGroupForm($dealid)
    {
        $deal = Deal::findOrFail($dealid);
        $visibilityGroups = VisibilityGroup::all(); // Get all groups

        return view('deals.assign_group', compact('deal', 'visibilityGroups'));
    }

    // Handle assignment
    public function assignGroup(Request $request, $dealid)
    {
        $request->validate([
            'visibility_group_id' => 'required|exists:visibility_groups,id',
        ]);

        $deal = Deal::find($dealid);
        // dd($lead);

        VisibilitySetting::updateOrCreate(
            ['user_id' => auth()->id(), 'item_type' => 'Deal', 'item_id' => $deal->id],
            ['visibility_group_id' => $request->visibility_group_id]
        );

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Deal assigned to group successfully.',
            ]);
        }

        return redirect()->route('deals.index')->with('success', 'Deals assigned to group successfully.');
    }
}
