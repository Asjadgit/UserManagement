<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use Illuminate\Http\Request;
use App\Models\VisibilityGroup;
use App\Models\VisibilitySetting;

class LeadController extends Controller
{
    public function index(Request $request)
    {
        $leads = Lead::all();
        if ($request->wantsJson()) {
            return response()->json([
                'leads' => $leads,
            ], 201);
        } else {
            return view('leads.index', compact('leads'));
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('leads.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
        ]);

        $lead = Lead::create(['name' => $request->name]);

        // Retrieve all permissions
        $leads = lead::all();

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'leads created successfully.',
                'leads' => $leads,
            ], 201);
        } else {
            return redirect()->route('leads.index')->with('success', 'leads Added Successfully');
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, $id)
    {
        $leads = lead::find($id);
        if ($request->wantsJson()) {
            return response()->json([
                'leads' => $leads,
            ], 200);
        } else {
            return view('leads.edit', compact('leads'));
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string',
        ]);

        $leads = lead::find($id);

        $leads->update(['name' => $request->name]);

        // Retrieve all permissions
        $leads = lead::all();
        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'leads updated successfully.',
                'leads' => $leads,
            ], 201);
        } else {
            return redirect()->route('leads.index')->with('success', 'leads updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id, Request $request)
    {

        // First, update the guard to 'web' before deleting
        $leads = lead::where('id', $id)->first();

        if (!$leads) {
            return response()->json([
                'error' => 'leads not found.'
            ], 404);
        }

        // Now safely delete the permission
        $leads->delete();

        // Return response based on request type
        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'leads deleted successfully.',
            ], 201);
        } else {
            return redirect()->route('leads.index')->with('success', 'leads deleted successfully.');
        }
    }


    // Show assign group form
    public function assignGroupForm($leadId)
    {
        $lead = Lead::findOrFail($leadId);
        $visibilityGroups = VisibilityGroup::all(); // Get all groups

        return view('leads.assign_group', compact('lead', 'visibilityGroups'));
    }

    // Handle assignment
    public function assignGroup(Request $request, $leadId)
    {
        $request->validate([
            'visibility_group_id' => 'required|exists:visibility_groups,id',
        ]);

        $lead = Lead::find($leadId);
        // dd($lead);

        VisibilitySetting::updateOrCreate(
            ['user_id' => auth()->id(), 'item_type' => 'Lead', 'item_id' => $lead->id],
            ['visibility_group_id' => $request->visibility_group_id]
        );

        if($request->wantsJson()){
            return response()->json([
                'message' => 'Lead assigned to group successfully.',
            ]);
        }

        return redirect()->route('leads.index')->with('success', 'Lead assigned to group successfully.');
    }
}
