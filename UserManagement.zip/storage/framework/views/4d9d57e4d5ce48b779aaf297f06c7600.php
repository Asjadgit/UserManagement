<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Add Members to <?php echo e($team->name); ?></div>
                    <div class="card-body">
                        <form id="addMembersForm">
                            <?php echo csrf_field(); ?>
                            <table id="usersTable" class="table table-bordered mt-3 p-2">
                                <thead>
                                    <tr>
                                        <th>Select</th>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Teams</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $usersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="user_ids[]" value="<?php echo e($user['id']); ?>"
                                                    class="user-checkbox"
                                                    <?php echo e(in_array($user['id'], $teamMemberIds) ? 'checked' : ''); ?>>
                                            </td>
                                            <td><?php echo e($user['id']); ?></td>
                                            <td><?php echo e($user['name']); ?></td>
                                            <td><?php echo e($user['email']); ?></td>
                                            <td>
                                                <?php if(count($user['teams']) > 0): ?>
                                                    <?php echo e(implode(', ', $user['teams'])); ?> <!-- Display team names -->
                                                <?php else: ?>
                                                    <span class="text-muted">Not in any team</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <button type="submit" class="btn btn-primary mt-3">Add Selected Members</button>
                            <a href="<?php echo e(route('teams.index')); ?>" class="btn btn-secondary mt-3">Go Back</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#usersTable').DataTable({
                "paging": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
                "lengthMenu": [
                    [5, 10, 25, 50, -1],
                    [5, 10, 25, 50, "All"]
                ],
                "language": {
                    "search": "Filter records:"
                }
            });

            let alreadySelected = <?php echo json_encode($teamMemberIds, 15, 512) ?>; // Already selected members

            $('#addMembersForm').submit(function(event) {
                event.preventDefault(); // Prevent default form submission

                let selectedUsers = [];
                $('.user-checkbox:checked').each(function() {
                    selectedUsers.push(parseInt($(this).val()));
                });

                let newlyAdded = selectedUsers.filter(id => !alreadySelected.includes(id));
                let removedUsers = alreadySelected.filter(id => !selectedUsers.includes(id));

                if (newlyAdded.length === 0 && removedUsers.length === 0) {
                    alert('Already Members of the team.');
                    return;
                }

                $.ajax({
                    url: "<?php echo e(route('teams.addMembers', $team->id)); ?>",
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        user_ids: selectedUsers
                    },
                    success: function(response) {
                        alert(response.message);
                        location.reload(); // Reload page to reflect changes
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);
                        alert('Something went wrong. Please try again.');
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/superadmin/team/members.blade.php ENDPATH**/ ?>