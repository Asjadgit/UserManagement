<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Plan Details: <?php echo e($plan->name); ?></div>
                    <div class="card-body">
                        <h5>Plan Name: <?php echo e($plan->name); ?></h5>
                        <hr>
                        <table class="table table-bordered mt-3">
                            <thead>
                                <tr align="center">
                                    <th class="text-center">Plan Name</th>
                                    <th class="text-center">Currency</th>
                                    <th class="text-center">Price</th>
                                    <th class="text-center">Frequency</th>
                                    <th class="text-center">Trial Days</th>
                                    <th class="text-center">Type</th>
                                    <th>Features</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr align="center">
                                    <td><?php echo e($plan->name); ?></td>
                                    <td><?php echo e($plan->currency); ?></td>
                                    <td><?php echo e($plan->price); ?></td>
                                    <td><?php echo e($plan->frequency); ?></td>
                                    <td><b><?php echo e($plan->trial_days); ?></b></td>
                                    <td><b><?php echo e($plan->type); ?></b></td>
                                    <td>
                                        <ul>
                                            <?php $__currentLoopData = json_decode($plan->features, true) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($feature); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <a href="<?php echo e(route('plans.edit', $plan->id)); ?>" class="btn btn-warning">Edit</a>
                        <a href="<?php echo e(route('plans.index')); ?>" class="btn btn-secondary">Go Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/superadmin/plan/show.blade.php ENDPATH**/ ?>