<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h4>Visibility Groups Management</h4>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('visibility_groups.create')); ?>" class="btn btn-primary mb-3">Add New Group</a>

                    <table id="visibilityGroupsTable" class="table table-bordered mt-3 p-2">
                        <thead>
                            <tr align="center">
                                <th class="text-center">Visibility Group Name</th>
                                <th class="text-center">Parent Group</th>
                                <th class="text-center">Users Count</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr align="center">
                                    <td><?php echo e($group->name); ?></td>
                                    <td><?php echo e($group->parent ? $group->parent->name : 'None'); ?></td>
                                    <td><?php echo e($group->users->count()); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('visibility_groups.show', $group->id)); ?>" class="btn btn-info btn-sm">View Group</a>

                                        <a href="<?php echo e(route('visibility_groups.edit', $group->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                                        <form action="<?php echo e(route('visibility_groups.destroy', $group->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                                        </form>

                                        <a href="<?php echo e(route('visibility_groups.create', ['parent_id' => $group->id])); ?>" class="btn btn-success btn-sm">Add Sub-Group</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#visibilityGroupsTable').DataTable({
            "paging": true,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            "lengthMenu": [
                [5, 10, 25, 50, -1],
                [5, 10, 25, 50, "All"]
            ],
            "language": {
                "search": "Filter records:"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/visibility-groups/index.blade.php ENDPATH**/ ?>