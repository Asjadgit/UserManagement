<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">User Details - <?php echo e($user->name); ?></div>

                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <th>Name:</th>
                                <td><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <th>Email:</th>
                                <td><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <th>Roles:</th>
                                <td>
                                    <?php if($user->roles->isEmpty()): ?>
                                        <span class="text-muted">No roles assigned</span>
                                    <?php else: ?>
                                        <?php echo e($user->roles->pluck('name')->join(', ')); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Permissions:</th>
                                <td>
                                    <?php if($user->roles->isEmpty()): ?>
                                        <span class="text-muted">No permissions assigned</span>
                                    <?php else: ?>
                                        <?php echo e($user->roles->flatMap->permissions->pluck('name')->unique()->join(', ')); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>

                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Back to List</a>
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary">Edit User</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/superadmin/users/show.blade.php ENDPATH**/ ?>