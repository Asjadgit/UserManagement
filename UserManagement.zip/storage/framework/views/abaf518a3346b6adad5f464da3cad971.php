<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Create Visibility Group</div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form action="<?php echo e(route('visibility_groups.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <!-- Group Name -->
                            <div class="mb-3">
                                <label for="name" class="form-label">Group Name</label>
                                <input type="text" name="name" id="name" class="form-control" maxlength="70" required>
                                <small id="nameCounter" class="text-muted">70 characters</small>
                            </div>

                            <!-- Description -->
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea name="description" id="description" class="form-control" maxlength="255"></textarea>
                                <small id="descCounter" class="text-muted">255 characters</small>
                            </div>

                            <!-- Parent Group (Optional) -->
                            <div class="mb-3">
                                <label for="parent_id" class="form-label">Parent Group (Optional)</label>
                                <select name="parent_id" id="parent_id" class="form-control">
                                    <option value="">None</option>
                                    <?php $__currentLoopData = $visibilityGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Submit & Back Buttons -->
                            <button type="submit" class="btn btn-success">Create Group</button>
                            <a href="<?php echo e(route('visibility_groups.index')); ?>" class="btn btn-secondary">Back</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <!-- JavaScript for Character Counter -->
     <script>
        document.addEventListener("DOMContentLoaded", function() {
            const nameInput = document.getElementById("name");
            const nameCounter = document.getElementById("nameCounter");
            const descInput = document.getElementById("description");
            const descCounter = document.getElementById("descCounter");

            nameInput.addEventListener("input", function() {
                nameCounter.textContent = `${nameInput.value.length}/70`;
            });

            descInput.addEventListener("input", function() {
                descCounter.textContent = `${descInput.value.length}/255`;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/visibility-groups/create.blade.php ENDPATH**/ ?>