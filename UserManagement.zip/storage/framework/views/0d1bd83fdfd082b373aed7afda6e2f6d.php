<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Group</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('visibility_groups.update', $group->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <!-- Group Name -->
                            <div class="mb-3">
                                <label for="name" class="form-label">Group Name</label>
                                <input type="text" name="name" id="name" class="form-control" maxlength="70"
                                    value="<?php echo e(old('name', $group->name)); ?>" required>
                                <small id="nameCounter" class="text-muted">0/70</small>
                            </div>

                            <!-- Description -->
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea name="description" id="description" class="form-control" maxlength="255"><?php echo e(old('description', $group->description)); ?></textarea>
                                <small id="descCounter" class="text-muted">0/255</small>
                            </div>

                            <!-- Parent Group (Optional) -->
                            <div class="mb-3">
                                <label for="parent_id" class="form-label">Parent Group (Optional)</label>
                                <select name="parent_id" id="parent_id" class="form-control">
                                    <option value="">None</option>
                                    <?php $__currentLoopData = $visibilityGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parentGroup->id); ?>"
                                            <?php echo e($group->parent_id == $parentGroup->id ? 'selected' : ''); ?>>
                                            <?php echo e($parentGroup->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Submit & Back Buttons -->
                            <button type="submit" class="btn btn-primary">Update Group</button>
                            <a href="<?php echo e(route('visibility_groups.index')); ?>" class="btn btn-secondary">Back</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript for Character Counter -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            function updateCounter(input, counter, maxLength) {
                counter.textContent = `${input.value.length}/${maxLength}`;
            }

            const nameInput = document.getElementById("name");
            const nameCounter = document.getElementById("nameCounter");
            const descInput = document.getElementById("description");
            const descCounter = document.getElementById("descCounter");

            // Initialize counters
            updateCounter(nameInput, nameCounter, 70);
            updateCounter(descInput, descCounter, 255);

            // Add event listeners
            nameInput.addEventListener("input", function() {
                updateCounter(nameInput, nameCounter, 70);
            });

            descInput.addEventListener("input", function() {
                updateCounter(descInput, descCounter, 255);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/visibility-groups/edit.blade.php ENDPATH**/ ?>