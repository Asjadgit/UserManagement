<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Currency Management</div>
                    <div class="card-body">
                        <a href="<?php echo e(route('currencies.create')); ?>" class="btn btn-primary mb-4">Add New Currency</a>

                        <table id="currencyTable" class="table table-bordered mt-3 p-2">
                            <thead>
                                <tr align="center">
                                    <th class="text-center">Country Name</th>
                                    <th class="text-center">Currency</th>
                                    <th class="text-center">Code</th>
                                    <th class="text-center">Symbol</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr align="center">
                                        <td><?php echo e($currency->country); ?></td>
                                        <td><?php echo e($currency->currency); ?></td>
                                        <td><?php echo e($currency->code); ?></td>
                                        <td><?php echo e($currency->symbol); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('currencies.show', $currency->id)); ?>" class="btn btn-info">View</a>
                                            <a href="<?php echo e(route('currencies.edit', $currency->id)); ?>" class="btn btn-warning">Edit</a>
                                            <form action="<?php echo e(route('currencies.destroy', $currency->id)); ?>" method="POST"
                                                class="d-inline">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('Are you sure?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function () {
        $('#currencyTable').DataTable({
            "paging": true,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
            "language": {
                "search": "Filter records:"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/superadmin/currency/index.blade.php ENDPATH**/ ?>