<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Assign Roles & Permissions to <?php echo e($user->name); ?></div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('users.updateRoles', ['id' => $user->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <h5>Assign Roles</h5>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>"
                                        class="form-check-input" <?php echo e($user->roles->contains($role) ? 'checked' : ''); ?>>
                                    <label class="form-check-label"><?php echo e($role->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <h5 class="mt-3">Permissions (Inherited from Roles)</h5>

                            <?php
                                // Get all assigned permissions from roles
                                $assignedPermissionIds = $user->roles->flatMap->permissions->pluck('id')->unique();
                            ?>

                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($assignedPermissionIds->contains($permission->id) ? 'checked' : ''); ?> disabled>
                                    <label class="form-check-label"><?php echo e($permission->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <button type="submit" class="btn btn-success mt-3">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/superadmin/users/assign-roles.blade.php ENDPATH**/ ?>