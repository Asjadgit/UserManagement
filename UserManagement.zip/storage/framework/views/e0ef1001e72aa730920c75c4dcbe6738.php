<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Add New Currency</div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form action="<?php echo e(route('currencies.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="country" class="form-label">Country Name</label>
                                <input type="text" class="form-control" id="country" name="country" required>
                            </div>

                            <div class="mb-3">
                                <label for="currency" class="form-label">Currency Name</label>
                                <input type="text" class="form-control" id="currency" name="currency" required>
                            </div>

                            <div class="mb-3">
                                <label for="code" class="form-label">Currency Code</label>
                                <input type="text" class="form-control" id="code" name="code" required>
                            </div>

                            <div class="mb-3">
                                <label for="symbol" class="form-label">Currency Symbol</label>
                                <input type="text" class="form-control" id="symbol" name="symbol" required>
                            </div>

                            <div class="mb-3">
                                <label for="thousand_separator" class="form-label">Thousand Separator</label>
                                <input type="text" class="form-control" id="thousand_separator" name="thousand_separator" maxlength="1" placeholder="e.g., , or .">
                            </div>

                            <div class="mb-3">
                                <label for="decimal_separator" class="form-label">Decimal Separator</label>
                                <input type="text" class="form-control" id="decimal_separator" name="decimal_separator" maxlength="1" placeholder="e.g., . or ,">
                            </div>

                            <button type="submit" class="btn btn-primary">Save Currency</button>

                            <a href="<?php echo e(route('currencies.index')); ?>" class="btn btn-secondary">Back</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\It-Linked-Projects\2025\UserManagement\resources\views/superadmin/currency/create.blade.php ENDPATH**/ ?>